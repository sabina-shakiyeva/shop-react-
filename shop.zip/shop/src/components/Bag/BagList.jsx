import { useEffect } from "react";
import BagItem from "./BagItem";
import { useDispatch, useSelector } from "react-redux";
import { getBag } from "../../store/reducers/bag/reducerBag";

function BagList() {
  let dispatch=useDispatch()
  let bag=useSelector((state)=>state.bag.bag)

  useEffect(() => {
    dispatch(getBag())
  }, []);


  return (
    <ul>
      {bag.map((item) => (
        <BagItem key={item.id} {...item} />
      ))}
    </ul>
  );
}

export default BagList;
