import { useDispatch, useSelector } from "react-redux";
import { order } from "../../store/reducers/bag/reducerBag";

function OrderForm() {
  let dispatch=useDispatch()
  let bag=useSelector((state)=>state.bag.bag)

  function handleOrderForm (ev) {
    ev.preventDefault()
    let formData = Object.fromEntries([...new FormData(ev.target)])
    dispatch(order(formData))
  }

  return (
    <div>
      <h1>Order Form</h1>
      <form onSubmit={handleOrderForm}>
        <input type="text" name="customer_name" placeholder="customer name" />
        <input type="text" name="customer_email" placeholder="customer email" />
        <input
          type="text"
          name="customer_address"
          placeholder="customer address"
        />
        <input
          type="text"
          name="customer_number"
          placeholder="customer number"
        />
        <button>ORDER</button>
      </form>
      <p>
        {bag.reduce((total, price) => total + price.total_price, 0)}
      </p>
    </div>
  );
}

export default OrderForm;
