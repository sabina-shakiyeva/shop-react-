import { useDispatch } from "react-redux";
import { deleteBag, minus, plus } from "../../store/reducers/bag/reducerBag";

function BagItem(props) {
 
  let dispatch=useDispatch()


  return (
    <li>
      <p>{props.product_name}</p>
      <p>{props.product_description}</p>
      <p>{props.product_price}</p>
      <img src={props.url} alt={props.product_name} />
      <button onClick={() => dispatch(deleteBag( props.id))}>DELETE</button>
      <div>
      <button onClick={() => dispatch(minus( props.id))}>-</button>
      <p>{props.count}</p>
      <button onClick={() => dispatch(plus(props.id))}>+</button>
      </div>
    </li>
  );
  }
  
  export default BagItem;
  