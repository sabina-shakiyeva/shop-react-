// export async function getOrders(dispatch){
//     let res = await fetch('http://localhost:5000/orders')
//     let data = await res.json()
//     dispatch({type:'GET ORDERS', payload: data})
// }


import { createAsyncThunk } from "@reduxjs/toolkit";
 
export let getOrders = createAsyncThunk(
  "content/getOrders",
  async function () {
    let res = await fetch("http://localhost:5000/orders");
    let data = await res.json();
    return data;
  }
);