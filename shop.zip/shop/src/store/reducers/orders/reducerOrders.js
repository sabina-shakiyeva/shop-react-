import { createSlice } from "@reduxjs/toolkit";
import {  getOrders } from "./orderFetchs";
let ordersSlice = createSlice({
  name:'orders',
  initialState:{
    orders:[],
    loading:false,
    error:null,
  },
  reducers:{
    getOrders:(state,action)=>{
      return { ...state, orders: action.payload };
    }

  },
  extraReducers:(builder)=>{
    builder.addCase(getOrders.pending,(state, action)=>{
      state.loading=true;
      state.error=null;
    })
    builder.addCase(getOrders.fulfilled,(state, action)=>{
      state.orders=action.payload;
      state.loading=false;
    })
    builder.addCase(getOrders.rejected,(state, action)=>{
      state.loading=false;
      state.error=true;
    })
  }
})
export const{getOrders}=ordersSlice.actions
export default ordersSlice.reducer;







// export let initialObjectOrders = {
//   orders: [],
// };

// export function reducerOrders(state  = initialObjectOrders, action) {
//   if (action.type === "GET ORDERS") {
//     return { ...state, orders: action.payload };
//   }
//   return state;
// }
