// export async function orderFetch(order){
//     let res = await fetch('http://localhost:5000/add-orders', {
//         method:'POST',
//         headers: {
//             'Content-type': 'application/json'
//         },
//         body:JSON.stringify(order)
//     })
//     let data = await res.json()
//     console.log(data)
// }

import { createAsyncThunk } from "@reduxjs/toolkit";
 
export let orderFetch = createAsyncThunk(
  "content/productFetch",
  async function () {
    let res = await fetch("http://localhost:5000/add-orders",{
        method:'POST',
        headers: {
            'Content-type': 'application/json'
        },
        body:JSON.stringify(order)

    })
          
    let data = await res.json();
    return data;
  }
);





