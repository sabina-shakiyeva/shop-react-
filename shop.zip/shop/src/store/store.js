import { configureStore } from "@reduxjs/toolkit"
import productsSlice from './reducers/products/reducerProducts'
import bagSlice from './reducers/bag/reducerBag'

const store = configureStore({
    reducer: {
        products: productsSlice,
        bag:bagSlice
    }
})

export default store